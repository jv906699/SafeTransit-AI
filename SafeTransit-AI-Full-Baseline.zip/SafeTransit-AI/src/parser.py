
from typing import Any

from tree_sitter import Parser
from tree_sitter_languages import get_language


class CodeParser:
    """Parse C and Python source code into Tree-sitter syntax trees."""

    SUPPORTED_LANGUAGES = {"c", "python"}

    def __init__(self) -> None:
        self._parsers: dict[str, Parser] = {}

        for language_name in self.SUPPORTED_LANGUAGES:
            language = get_language(language_name)
            parser = Parser()
            parser.set_language(language)
            self._parsers[language_name] = parser

    def parse(self, source_code: str, language: str) -> Any:
        """Parse source code and return its syntax tree."""
        language = language.lower()

        if language not in self.SUPPORTED_LANGUAGES:
            raise ValueError(
                f"Unsupported language: {language}. "
                f"Supported languages: "
                f"{sorted(self.SUPPORTED_LANGUAGES)}"
            )

        if not source_code.strip():
            raise ValueError("Source code cannot be empty.")

        parser = self._parsers[language]
        return parser.parse(source_code.encode("utf-8"))

    def has_syntax_errors(self, tree: Any) -> bool:
        """Check whether the syntax tree contains parsing errors."""
        return tree.root_node.has_error


class ASTGraphWalker:
    """Traverse Tree-sitter syntax trees using depth-first search."""

    def walk(self, tree: Any) -> list[dict[str, Any]]:
        """Return metadata for every node in the syntax tree."""
        results: list[dict[str, Any]] = []
        stack = [tree.root_node]

        while stack:
            node = stack.pop()

            results.append(
                {
                    "type": node.type,
                    "text": node.text.decode(
                        "utf-8", errors="replace"
                    ),
                    "start_point": node.start_point,
                    "end_point": node.end_point,
                    "has_error": node.has_error,
                }
            )

            stack.extend(reversed(node.children))

        return results

    def find_nodes(
        self,
        tree: Any,
        node_types: set[str],
    ) -> list[dict[str, Any]]:
        """Find nodes matching the requested Tree-sitter types."""
        return [
            node
            for node in self.walk(tree)
            if node["type"] in node_types
        ]


class CStructuralAnalyzer:
    """Identify selected structural patterns in C source code."""

    MEMORY_FUNCTIONS = {"malloc", "calloc", "realloc", "free"}

    def __init__(self) -> None:
        self.parser = CodeParser()
        self.walker = ASTGraphWalker()

    def _iter_nodes(self, root: Any):
        """Yield AST nodes using depth-first traversal."""
        stack = [root]

        while stack:
            node = stack.pop()
            yield node
            stack.extend(reversed(node.children))

    def _get_called_function_name(self, node: Any) -> str | None:
        """Extract a function name from a call_expression AST node."""
        function_node = node.child_by_field_name("function")

        if function_node is None:
            return None

        # Handle ordinary calls such as malloc(...) and free(...).
        if function_node.type == "identifier":
            return function_node.text.decode("utf-8", errors="replace")

        # Ignore indirect calls and more complex expressions for now.
        return None

    def analyze(self, source_code: str) -> dict[str, Any]:
        """Return structural findings for a C source snippet."""
        tree = self.parser.parse(source_code, "c")
        nodes = self.walker.walk(tree)
        ast_nodes = list(self._iter_nodes(tree.root_node))

        functions = [
            node for node in nodes
            if node["type"] == "function_definition"
        ]

        memory_calls = [
            node.text.decode("utf-8", errors="replace")
            for node in ast_nodes
            if (
                node.type == "call_expression"
                and self._get_called_function_name(node)
                in self.MEMORY_FUNCTIONS
            )
        ]

        pointer_declarations = [
            node for node in nodes
            if node["type"] == "pointer_declarator"
        ]

        pointer_expressions = [
            node for node in nodes
            if node["type"] == "pointer_expression"
        ]

        array_accesses = [
            node for node in nodes
            if node["type"] == "subscript_expression"
        ]

        return {
            "language": "c",
            "syntax_errors": self.parser.has_syntax_errors(tree),
            "function_count": len(functions),
            "functions": [node["text"] for node in functions],
            "memory_management_calls": memory_calls,
            "pointer_declaration_count": len(pointer_declarations),
            "pointer_expression_count": len(pointer_expressions),
            "array_access_count": len(array_accesses),
        }

class StructuralAnalyzer:
    """Extract basic structural information from C or Python source."""

    STRING_NODE_TYPES = {
        "string_literal",  # C
        "string",          # Python
    }

    def __init__(self) -> None:
        self.parser = CodeParser()
        self.walker = ASTGraphWalker()

    def analyze(
        self,
        source_code: str,
        language: str,
    ) -> dict[str, Any]:
        """Report identifiers, strings, functions, and source positions."""
        language = language.lower()
        tree = self.parser.parse(source_code, language)
        nodes = self.walker.walk(tree)

        identifiers = [
            node for node in nodes
            if node["type"] == "identifier"
        ]

        string_literals = [
            node for node in nodes
            if node["type"] in self.STRING_NODE_TYPES
        ]

        functions = [
            node for node in nodes
            if node["type"] == "function_definition"
        ]

        blocks = [
            node for node in nodes
            if node["type"] in {"compound_statement", "block"}
        ]

        return {
            "language": language,
            "syntax_errors": self.parser.has_syntax_errors(tree),
            "identifier_count": len(identifiers),
            "identifiers": [node["text"] for node in identifiers],
            "string_literal_count": len(string_literals),
            "string_literals": [
                node["text"] for node in string_literals
            ],
            "function_count": len(functions),
            "block_count": len(blocks),
            "blocks": [
                {
                    "type": node["type"],
                    "start_point": node["start_point"],
                    "end_point": node["end_point"],
                }
                for node in blocks
            ],
        }


def string_to_ast_tree(source_code: str, language: str) -> Any:
    """Convert source code into a Tree-sitter syntax tree."""
    parser = CodeParser()
    return parser.parse(source_code, language)
