
from pathlib import Path

# Project paths
PROJECT_ROOT = Path(__file__).resolve().parent.parent
SRC_DIR = PROJECT_ROOT / "src"
SANDBOX_DIR = PROJECT_ROOT / "sandbox"
DATA_DIR = PROJECT_ROOT / "data"
BENCHMARKS_DIR = DATA_DIR / "benchmarks"
TESTS_DIR = PROJECT_ROOT / "tests"

# Input limits
MAX_SOURCE_SIZE_BYTES = 1_000_000
MAX_SOURCE_LINES = 10_000

# Pipeline safety limits
MAX_REPAIR_ATTEMPTS = 4
DEFAULT_LANGUAGE = "c"

# Supported source languages
SUPPORTED_LANGUAGES = ("c", "python")


def ensure_project_directories() -> None:
    """Create required runtime directories if they do not exist."""
    for directory in (
        SANDBOX_DIR,
        BENCHMARKS_DIR,
        TESTS_DIR,
    ):
        directory.mkdir(parents=True, exist_ok=True)
