"""Repair-agent adapter backed by a local Ollama server."""

from .ollama_client import OllamaClient
from .agent import RepairResponse


class OllamaRepairAgent:
    """Generate repaired source using Ollama and normalize its output."""

    SYSTEM_PROMPT = (
        "You are a careful C programmer. Repair code using the "
        "provided diagnostics. Preserve intended behavior and make "
        "the smallest necessary changes. Return complete C source "
        "code only, without Markdown fences or explanations."
    )

    def __init__(
        self,
        client: OllamaClient,
        cleanup_fn,
    ) -> None:
        self.client = client
        self.cleanup_fn = cleanup_fn

    def repair(self, source_code: str, diagnostics: str) -> RepairResponse:
        if not source_code.strip():
            raise ValueError("Source code cannot be empty.")
        if not diagnostics.strip():
            raise ValueError("Diagnostics cannot be empty.")

        prompt = (
            "Repair the following C source code.\n\n"
            "Compiler or validation diagnostics:\n"
            f"{diagnostics}\n\n"
            "Source code:\n"
            f"{source_code}\n"
        )

        result = self.client.generate(
            prompt=prompt,
            system=self.SYSTEM_PROMPT,
            temperature=0.1,
            top_p=0.9,
        )

        cleaned_code = self.cleanup_fn(result.response)
        if not cleaned_code.strip():
            raise ValueError("Ollama returned empty source code.")

        return RepairResponse(
            raw_output=result.response,
            cleaned_code=cleaned_code,
        )
