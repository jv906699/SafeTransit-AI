"""Inference agent adapter for the SafeTransit-AI prototype."""

from dataclasses import dataclass
from typing import Callable


@dataclass
class RepairResponse:
    """Raw and normalized output from the inference model."""

    raw_output: str
    cleaned_code: str


class LocalInferenceAgent:
    """Wrap a supplied inference function behind a stable interface."""

    def __init__(
        self,
        inference_fn: Callable[[str, str], str],
        cleanup_fn: Callable[[str], str],
    ) -> None:
        self._inference_fn = inference_fn
        self._cleanup_fn = cleanup_fn

    def repair(
        self,
        source_code: str,
        diagnostics: str,
    ) -> RepairResponse:
        """Generate a repair and normalize the returned source."""
        if not source_code.strip():
            raise ValueError("Source code cannot be empty.")

        if not diagnostics.strip():
            raise ValueError("Diagnostics cannot be empty.")

        raw_output = self._inference_fn(source_code, diagnostics)
        cleaned_code = self._cleanup_fn(raw_output)

        if not cleaned_code.strip():
            raise ValueError("The model returned empty source code.")

        return RepairResponse(
            raw_output=raw_output,
            cleaned_code=cleaned_code,
        )
