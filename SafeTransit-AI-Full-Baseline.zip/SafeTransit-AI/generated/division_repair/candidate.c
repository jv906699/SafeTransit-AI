#include <stdio.h>

int divide_numbers(int a, int b) {
    return a / b;
}

int main(void) {
    printf("%d\n", divide_numbers(20, 4));
    printf("%d\n", divide_numbers(15, 3));
    return 0;
}