#include <stdio.h>

int main(void) {
    int total = 10;
    printf("Total: %d\n", total);
    return 0;
}