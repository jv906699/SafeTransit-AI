
#include <stdio.h>

int add_numbers(int a, int b) {
    return a + b;
}

int main(void) {
    printf("%d\n", add_numbers(2, 3));
    printf("%d\n", add_numbers(-4, 9));
    printf("%d\n", add_numbers(0, 0));
    return 0;
}
