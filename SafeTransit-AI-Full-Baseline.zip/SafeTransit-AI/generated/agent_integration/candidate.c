#include <stdio.h>

int main(void) {
    printf("SafeTransit test\n");
    return 0;
}