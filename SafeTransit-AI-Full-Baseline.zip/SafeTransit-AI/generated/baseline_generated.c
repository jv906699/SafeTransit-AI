#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int *values = malloc(5 * sizeof(int));
    if (values == NULL) {
        return 1;
    }

    for (size_t i = 0; i < 5; i++) {
        values[i] = i * 2;
    }

    printf("%d\n", values[4]);
    free(values);
    return 0;
}
