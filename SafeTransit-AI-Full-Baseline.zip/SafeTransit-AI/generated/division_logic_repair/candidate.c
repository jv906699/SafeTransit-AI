#include <stdio.h>

int divide_numbers(int a, int b) {
    if (b != 0) {
        return a / b;
    } else {
        return 0; // Handle division by zero
    }
}

int main(void) {
    printf("%d\n", divide_numbers(20, 4));
    printf("%d\n", divide_numbers(15, 3));
    return 0;
}